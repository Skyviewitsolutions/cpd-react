import React from "react";
import "./Student_cv.css";
import Header from "../Header/Homepage_header";
import Footer from "../Footer/Footer";
import Form from "react-bootstrap/Form";

import { useLocation, useNavigate } from "react-router-dom";
import { useState } from "react";
import { toast, ToastContainer } from "react-toastify";
import axios from "axios";
import { useEffect } from "react";
import { endpoints } from "../services/endpoints";
import Spinner from "react-bootstrap/Spinner";
import Homepage_header from "../Header/Homepage_header";
import { BsFillPlusCircleFill } from "react-icons/bs";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import { FiEdit } from "react-icons/fi";
import { MdAddCircle } from "react-icons/md";
import { FiSearch } from "react-icons/fi";
import "../../../src/fonts/Inter-Bold.ttf";
import "../../../src/fonts/Inter-Regular.ttf";
// import { TagsInput } from "react-tag-input-component";
import { CgAttachment } from "react-icons/cg";
import { BiCurrentLocation } from "react-icons/bi";
import educationLogo from '../../assets/Images/educationLogo.png';
import company_logo from '../../assets/Images/company_logo.png';
import $ from "jquery";

const Student_cv = () => {
  const navigate = useNavigate("");
  const location = useLocation("");

  const [allDomain, setAlldomain] = useState([]);
  const [allIndustry, setAllIndustry] = useState([]);
  const [loading, setLoading] = useState(false);
  const [name, setName] = useState("");
  const [lName, setLname] = useState("");
  const [contact, setContact] = useState("");
  const [nationality, setNationality] = useState("");
  const [dob, setDob] = useState("");
  const [gender, setGender] = useState("");
  const [uploadCv, setUploadCv] = useState(null);
  const [school, setSchool] = useState([]);
  const [startYear, setStartYear] = useState([]);
  const [endYear, setEndYear] = useState([]);
  const [program, setProgram] = useState([]);
  const [fieldStudy, setFieldStudy] = useState([]);
  const [domain, setDomain] = useState("");
  const [industry, setIndustry] = useState("");
  const [skills, setSkills] = useState("");
  const [description, setDescription] = useState("");
  const [avtarFile, setAvtarFile] = useState(null);
  const [cvFIle, setCvFile] = useState("");
  const [allNational, setAllNational] = useState([]);
  const [update, setUpdate] = useState(false);

  const cvUrl = "https://admin.cpdedu.com/api/v1/upload-cv";

  const token = localStorage.getItem("token");
  var userDetails = localStorage.getItem("users");
  // console.log(userDetails, "user details..");

  const submit = () => {
    if (name === "") {
      toast("Please enter first name", { type: "warning" });
    } else if (lName === "") {
      toast("Please enter last name", { type: "warning" });
    } else if (contact === "") {
      toast("Please enter contact", { type: "warning" });
    } else if (nationality === "") {
      toast("Please enter nationality", { type: "error" });
    } else if (dob === "") {
      toast("Please enter DOB", { type: "warning" });
    } else if (gender === "") {
      toast("Please enter gender", { type: "warning" });
    } else if (uploadCv === "") {
      toast("Please upload CV", { type: "warning" });
    } else if (domain === "") {
      toast("Please enter domain", { type: "warning" });
    } else if (industry === "") {
      toast("Please enter industry", { type: "warning" });
    } else {
      $(".student_records :input").each(function () {
        if (this.value == "") {
          toast($(this).attr("error"), { type: "warning" });
          $(this).focus();
          throw new Error("Here we stop");
        }
        if ($(this).hasClass("school")) {
          school.push(this.value);
        }
        if ($(this).hasClass("start-year")) {
          startYear.push(this.value);
        }
        if ($(this).hasClass("end-year")) {
          endYear.push(this.value);
        }
        if ($(this).hasClass("program")) {
          program.push(this.value);
        }
        if ($(this).hasClass("field")) {
          fieldStudy.push(this.value);
        }
      });
      $(".customer_records_dynamic .row").each(function () {
        $(":input", this).each(function () {
          if (this.value == "") {
            toast($(this).attr("error"), { type: "warning" });
            $(this).focus();
            throw new Error("Here we stop");
          }
          if ($(this).hasClass("school")) {
            school.push(this.value);
          }
          if ($(this).hasClass("start-year")) {
            startYear.push(this.value);
          }
          if ($(this).hasClass("end-year")) {
            endYear.push(this.value);
          }
          if ($(this).hasClass("program")) {
            program.push(this.value);
          }
          if ($(this).hasClass("field")) {
            fieldStudy.push(this.value);
          }
        });
      });
      const formData = new FormData();
      formData.append("first_name", name);
      formData.append("last_name", lName);
      formData.append("contact_number", contact);
      formData.append("nationality", nationality);
      formData.append("dob", dob);
      formData.append("gender", gender);
      formData.append("university_name", school);
      formData.append("start_year", startYear);
      formData.append("end_year", endYear);
      formData.append("program", program);
      formData.append("field_of_study", fieldStudy);
      formData.append("domain", domain);
      formData.append("description", description);
      formData.append("industry", industry);
      formData.append("cv_file", uploadCv);
      formData.append("avtar_file", avtarFile);

      const headers = {
        Authorization: `Bearer ${token}`,
        "Content-Type": "multipart/form-data",
      };

      setLoading(true);

      axios
        .post(cvUrl, formData, { headers: headers })
        .then((res) => {
          setLoading(false);
          if (res.data.result === true) {
            toast("Profile created successfully", { type: "success" });
            navigate("/");
          }
        })
        .catch((err) => {
          console.log(err, "error");
          setLoading(false);
        });
    }
  };

  const handleChange = (e) => {
    var cvFiles = e.target.files[0];
    // setUploadCv(cvFiles);
  };
  const handleImage = (e) => {
    var imgFiles = e.target.files[0];
    setAvtarFile(imgFiles);
  };

  const domainUrl = "https://admin.cpdedu.com/api/v1/list-domain";

  const getDomain = () => {
    const headers = {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    };

    axios
      .get(domainUrl, { headers: headers })
      .then((res) => {
        if (res.data.result === true) {
          setAlldomain(res.data.data);
        } else if (res.data.result === false) {
          toast(res.data.message, { type: "error" });
        }
      })
      .catch((err) => {
        console.log(err, "error");
      });
  };

  const getIndustry = () => {
    const industryUrl = "https://admin.cpdedu.com/api/v1/list-industry";
    const headers = {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    };

    axios
      .get(industryUrl, { headers: headers })
      .then((res) => {
        if (res.data.result === true) {
          setAllIndustry(res.data.data);
        } else if (res.data.result === false) {
          toast(res.data.message, { type: "error" });
        }
      })
      .catch((err) => {
        console.log(err, "error");
      });
  };

  const getNationality = () => {
    const headers = {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    };

    const url = endpoints.events.getNationalityUrl;

    axios
      .get(url, { headers: headers })
      .then((res) => {
        if (res.status === 200) {
          const val = res.data;

          setAllNational(val);
        }
      })
      .catch((err) => {
        console.log(err, "this is the error");
      });
  };

  useEffect(() => {
    getDomain();
    getIndustry();
    getNationality();
  }, []);

  // here we are going to work on the updation part;

  const usersData = location?.state?.usersData;
  // console.log(usersData, "all location data here...");
  console.log(usersData, "users data");

  useEffect(() => {
    if (Object.keys(usersData).length) {
      setUpdate(true);
      setName(usersData.first_name);
      setLname(usersData.last_name);
      setContact(usersData.contact_number);
      setNationality(usersData.nationality);
      var dobs = usersData.dob.replaceAll("/", "-");
      setDob(dobs);
      setGender(usersData.gender);
      let education_length = JSON.parse(usersData.university_name).length;
      for (let j = 2; j <= education_length; j++) {
        generateMultipleDiv();
      }
      for (let i = 1; i <= education_length; i++) {
        if (i == 1) {
          $(".student_records :input").each(function () {
            if ($(this).hasClass("school")) {
              $(this).val(JSON.parse(usersData.university_name)[i - 1]);
            }
            if ($(this).hasClass("start-year")) {
              $(this).val(JSON.parse(usersData.start_year)[i - 1]);
            }
            if ($(this).hasClass("end-year")) {
              $(this).val(JSON.parse(usersData.end_year)[i - 1]);
            }
            if ($(this).hasClass("program")) {
              $(this).val(JSON.parse(usersData.program)[i - 1]);
            }
            if ($(this).hasClass("field")) {
              $(this).val(JSON.parse(usersData.field_of_study)[i - 1]);
            }
          });
        } else {
          $(".customer_records_dynamic :input").each(function () {
            if ($(this).hasClass("school")) {
              $(this).val(JSON.parse(usersData.university_name)[i - 1]);
            }
            if ($(this).hasClass("start-year")) {
              $(this).val(JSON.parse(usersData.start_year)[i - 1]);
            }
            if ($(this).hasClass("end-year")) {
              $(this).val(JSON.parse(usersData.end_year)[i - 1]);
            }
            if ($(this).hasClass("program")) {
              $(this).val(JSON.parse(usersData.program)[i - 1]);
            }
            if ($(this).hasClass("field")) {
              $(this).val(JSON.parse(usersData.field_of_study)[i - 1]);
            }
          });
        }
      }
      setDomain(usersData.domain);
      setIndustry(usersData.industry);
      setDescription(usersData.description);

      var imgUrl = location.state.imageUrl;
      const fileName = "myFile.jpg";

      fetch(imgUrl).then(async (response) => {
        const contentType = response.headers.get("content-type");
        const blob = await response.blob();
        const file = new File([blob], fileName, { contentType });
        setAvtarFile(file);
      });
    }
  }, [usersData]);

  const generateMultipleDiv = () => {
    $(".customer_records_dynamic").append($(".student_records").html());
    $(".customer_records_dynamic .row .removeDiv").html(
      '<a href="#" class="remove-field btn-remove-customer">Remove</a>'
    );
  };

  useEffect(() => {
    $(document).on("click", ".remove-field", function (e) {
      $(this).closest(".row").remove();
      e.preventDefault();
    });
  }, []);

  const updateProfile = () => {
    const url = endpoints.authentication.updateProfile;
    console.log(url, "all url...");
    console.log("School", school, typeof school);
    if (name === "") {
      toast("Please enter first name", { type: "warning" });
    } else if (lName === "") {
      toast("Please enter last name", { type: "warning" });
    } else if (contact === "") {
      toast("Please enter contact", { type: "warning" });
    } else if (nationality === "") {
      toast("Please enter nationality", { type: "error" });
    } else if (dob === "") {
      toast("Please enter DOB", { type: "warning" });
    } else if (gender === "") {
      toast("Please enter gender", { type: "warning" });
    } else if (uploadCv === "") {
      toast("Please upload CV", { type: "warning" });
    } else if (domain === "") {
      toast("Please enter domain", { type: "warning" });
    } else if (industry === "") {
      toast("Please enter industry", { type: "warning" });
    } else {
      $(".student_records :input").each(function () {
        if (this.value == "") {
          toast($(this).attr("error"), { type: "warning" });
          $(this).focus();
          throw new Error("Here we stop");
        }
        if ($(this).hasClass("school")) {
          if (!school.includes(this.value)) {
            school.push(this.value);
          }
        }
        if ($(this).hasClass("start-year")) {
          if (!startYear.includes(this.value)) {
            startYear.push(this.value);
          }
        }
        if ($(this).hasClass("end-year")) {
          if (!endYear.includes(this.value)) {
            endYear.push(this.value);
          }
        }
        if ($(this).hasClass("program")) {
          if (!program.includes(this.value)) {
            program.push(this.value);
          }
        }
        if ($(this).hasClass("field")) {
          if (!fieldStudy.includes(this.value)) {
            fieldStudy.push(this.value);
          }
        }
      });
      $(".customer_records_dynamic .row").each(function () {
        $(":input", this).each(function () {
          if (this.value == "") {
            toast($(this).attr("error"), { type: "warning" });
            $(this).focus();
            throw new Error("Here we stop");
          }
          if ($(this).hasClass("school")) {
            if (!school.includes(this.value)) {
              school.push(this.value);
            }
          }
          if ($(this).hasClass("start-year")) {
            if (!startYear.includes(this.value)) {
              startYear.push(this.value);
            }
          }
          if ($(this).hasClass("end-year")) {
            if (!endYear.includes(this.value)) {
              endYear.push(this.value);
            }
          }
          if ($(this).hasClass("program")) {
            if (!program.includes(this.value)) {
              program.push(this.value);
            }
          }
          if ($(this).hasClass("field")) {
            if (!fieldStudy.includes(this.value)) {
              fieldStudy.push(this.value);
            }
          }
        });
      });
      const formData = new FormData();
      formData.append("first_name", name);
      formData.append("last_name", lName);
      formData.append("contact_number", contact);
      formData.append("nationality", nationality);
      formData.append("dob", dob);
      formData.append("gender", gender);
      formData.append("university_name", JSON.stringify(school));
      formData.append("start_year", JSON.stringify(startYear));
      formData.append("end_year", JSON.stringify(endYear));
      formData.append("program", JSON.stringify(program));
      formData.append("field_of_study", JSON.stringify(fieldStudy));
      formData.append("domain", domain);
      formData.append("description", description);
      formData.append("industry", industry);
      formData.append("cv_file", uploadCv);
      if (avtarFile != null) {
        formData.append("avtar_file", avtarFile);
      }

      const headers = {
        Authorization: `Bearer ${token}`,
        "Content-Type": "multipart/form-data",
      };

      setLoading(true);

      axios
        .post(url, formData, { headers: headers })
        .then((res) => {
          setLoading(false);
          if (res.data.result === true) {
            toast("Profile updated successfully", { type: "success" });
            navigate("/");
          }
        })
        .catch((err) => {
          console.log(err, "error");
          setLoading(false);
        });
    }
  };

  const getAcedemicYears = () => {
    let currentYear = new Date().getFullYear();
    let options = [];
    for (let i = currentYear; i >= 1950; i--) {
      options.push(<option value={i}>{i}</option>);
    }
    return options;
  };

  return (
    <>
      <Homepage_header />
      <div className="container ">
        <h3 id="create_resume">
          Please fill some details to create your resume
        </h3>
        <div className="formoutline_studentcv">
          <div className="row ">
            {/* <button className="btn btn-success cvedit ">Edit</button> font-size: 30px;*/}
            <h5 className="personal_details_heading">Personal Details</h5>
            <div className="col-lg-12 col-md-12 col-12">
              <div className="row">
                <div className="col-lg-4 col-md-12 col-12 ">
                  <div class="form-group">
                    <label for="exampleInputPassword1">First Name</label>
                    <input
                      type="text"
                      class="form-control "
                      id="exampleInputPassword1"
                      placeholder="Enter First Name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                    />
                  </div>
                </div>
                <div className="col-lg-4 col-md-12 col-12 ">
                  <div class="form-group">
                    <label for="exampleInputPassword1">Last Name</label>
                    <input
                      pattern="[0-9]{10}"
                      type="text"
                      class="form-control "
                      id="exampleInputPassword1"
                      placeholder="Enter Last Name"
                      value={lName}
                      onChange={(e) => setLname(e.target.value)}
                    />
                  </div>
                </div>

                <div className="col-lg-4 col-md-12 col-12 ">
                  <div class="form-group">
                    <label for="mobile_code">Contact</label>
                   
                    <PhoneInput
                      country={"sg"}
                      value={contact}
                      onChange={(phone) => setContact(phone)}
                    />
                    
                  </div>
                </div>

                <div className="col-12 col-md-12 col-lg-4 ">
                  <div class="form-group">
                    <label for="">Nationality</label>
                    <select
                      class="form-select  "
                      aria-label="select example"
                      value={nationality}
                      onChange={(e) => setNationality(e.target.value)}
                    >
                      <option>Choose Nationality</option>
                      {allNational.map((itm, ind) => {
                        return (
                          <>
                            <option value={itm.en_short_name}>
                              {itm.en_short_name}
                            </option>
                          </>
                        );
                      })}
                    </select>
                  </div>
                </div>
                <div className="col-12 col-md-12 col-lg-4 ">
                  <div class="form-group">
                    <label for="">Date of Birth</label>
                    <input
                      type="date"
                      class="form-control "
                      placeholder="Due date"
                      value={dob}
                      onChange={(e) => setDob(e.target.value)}
                    />
                  </div>
                </div>
                <div className="col-12 col-md-12 col-lg-4 ">
                  <div class="form-group">
                    <label for="">Gender</label>
                    <select
                      className="form-select "
                      aria-label="Default select example"
                      value={gender}
                      onChange={(e) => setGender(e.target.value)}
                    >
                      <option>Choose Gender</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                    </select>
                  </div>
                </div>
            


                <div className="col-6 col-md-6 col-lg-4 ">
                  <div class="form-group">
                    <label for="" htmlFor="takePhoto">
                      Upload Img
                    </label>
                    <input
                      type="file"
                      class="form-control"
                      placeholder="Enter here"
                      accept="image/png, image/gif, image/jpeg"
                      onChange={(e) => handleImage(e)}
                    />
                  </div>
                </div>
                </div>

              {/* {
                  userDetails.user_type==1
                  ? */}
              {/* <> */}
              <h5
                className="heading_second"
                style={{
                  display: "flex",
                  flexDriection: "row",
                  justifyContent: "space-between",
                }}
              >
                Education Details
                <a
                  class="extra-fields-customer"
                  style={{ cursor: "pointer" }}
                  onClick={() => {
                    generateMultipleDiv();
                  }}
                >
                  <BsFillPlusCircleFill fontSize={20} />
                </a>
              </h5>

              <div className="studentcv_experiencelogoBox">
<div className="studentCV_logobox"> 
<img src={educationLogo} alt=""/>
<div className="studentCV_universityDetail d-lg-block d-none">
  <h5>KYUNG HEE UNIVERSITY</h5>
  
  <h6>Master of Business Administration</h6>
  <h6>2018-2022</h6>
</div></div>
<div className="studentCV_rightIcon">
<FiEdit  style={{color:"gray"}}/>
                  <MdAddCircle />
                </div>
</div>



              <div className="student_records">
                <div className="row">
                  <div className="col-lg-6 col-md-12 col-12">
                    <label for="">School/College/University*</label>
                    <input
                      type="text"
                      class="form-control school"
                      id=""
                      placeholder="Enter here"
                      error="Please enter School/College/University"
                    />
                  </div>

                  <div className="col-lg-3 col-md-12 col-12">
                    <div class="form-group">
                      <label for="">Start year*</label>
                      <select
                        class="form-select start-year "
                        aria-label="Default select example"
                        error="Please enter start year"
                      >
                        <option>Choose Start Year</option>
                        {getAcedemicYears()}
                      </select>
                    </div>
                  </div>

                  <div className="col-lg-3 col-md-12 col-12 ">
                    <div class="form-group">
                      <label for="exampleInputPassword1">End year*</label>
                      <select
                        class="form-select end-year "
                        aria-label="Default select example"
                        error="Please enter end year"
                      >
                        <option>Choose End Year</option>
                        {getAcedemicYears()}
                      </select>
                    </div>
                  </div>
                  <div className="col-lg-4 col-md-12 col-12 ">
                    <div class="form-group">
                      <label for="">Program</label>
                      <input
                        type="text"
                        class="form-control program"
                        placeholder="Enter here"
                        error="Please enter program"
                      />
                    </div>
                  </div>
                  <div className="col-lg-4 col-md-12 col-12">
                    <div class="form-group">
                      <label for="">Field Study</label>
                      <input
                        type="text"
                        class="form-control field"
                        id=""
                        placeholder="Enter here"
                        error="Please enter field study"
                      />
                    </div>
                  </div>
                  <div className="col-lg-4 col-md-12 col-12 ">
                    <button className="addExperiencebutton">
                      {" "}
                      Add Education
                    </button>
                  </div>
                  <div
                    className="col-lg-4 col-md-12 col-12  removeDiv"
                    style={{ display: "flex", alignItems: "center" }}
                  ></div>
                </div>
              </div>
              <div class="customer_records_dynamic"></div>
              {/* </> */}
              {/* // : null */}

              {/* // } */}

              <h5 className="heading_second">Add Experience</h5>

              <div className="studentcv_experiencelogoBox">
<div className="studentCV_logobox"> 
<img src={company_logo} alt=""/>
<div className="studentCV_universityDetail d-lg-block d-none">
  <h5>Marketing Manager</h5>
  
  <h6>IT Company</h6>
  <h6>2018-2022</h6>
</div></div>
<div className="studentCV_rightIcon">
<FiEdit  style={{color:"gray"}}/>
                  <MdAddCircle />
                </div>
</div>


              <div className="row">
                <div className="col-12 col-md-12 col-lg-4 ">
                  <div class="form-group">
                    <label for="exampleInputPassword1">Job Title</label>
                    <select
                      class="form-select end-year "
                      aria-label="Default select example"
                    >
                      <option>select</option>
                    </select>
                  </div>
                </div>

                <div className="col-12 col-md-12 col-lg-4 ">
                  <div class="form-group">
                    <label for="exampleInputPassword1">Employment Type</label>
                    <select
                      class="form-select end-year "
                      aria-label="Default select example"
                    >
                      <option>select</option>
                    </select>
                  </div>
                </div>
                <div className="col-lg-4 col-md-12 col-12 ">
                  <div class="form-group">
                    <label for="exampleInputPassword1">Select Company</label>
                    <select
                      class="form-select end-year "
                      aria-label="Default select example"
                    >
                      <option>select</option>
                    </select>
                  </div>
                </div>
                
             
                <div className="col-lg-3 col-md-12 col-12 ">
                  <div class="form-group">
                    <label for="exampleInputPassword1">Start Year</label>
                    <select
                      class="form-select end-year "
                      aria-label="Default select example"
                    >
                      <option>select</option>
                    </select>
                  </div>
                </div>
                
                <div className="col-lg-3 col-md-12 col-12 ">
                  <div class="form-group">
                    <label for="exampleInputPassword1">End Year</label>
                    <select
                      class="form-select end-year "
                      aria-label="Default select example"
                    >
                      <option>select</option>
                    </select>
                  </div>
                </div>

                <div className="col-lg-6 col-md-12 col-12 ">
                  <div class="form-group studentCV_ExperienceCheckbox">
                    <input
                      class="form-check-input"
                      type="checkbox"
                      value=""
                      id="flexCheckDefault"
                    />
                    <label
                      class="form-check-label studentCV_checkLabel"
                      for="flexCheckDefault"
                    >
                      I am currently working in this role
                    </label>
                  </div>
                </div>
             
                <div className="col-lg-4 col-md-12 col-12 ">
                  <div class="form-group">
                    <label for="exampleInputPassword1">Domain</label>
                    <select
                      class="form-select  "
                      aria-label="Default select example"
                      placeholder="Technology"
                      value={domain}
                      onChange={(e) => setDomain(e.target.value)}
                    >
                      <option>Choose Domain</option>
                      {allDomain.map((item, index) => {
                        return (
                          <>
                            <option value={item.title}>{item.title}</option>
                          </>
                        );
                      })}
                    </select>
                  </div>
                </div>

                <div className="col-lg-4 col-md-12 col-12 ">
                  <div class="form-group">
                    <label for="exampleInputPassword1">Industry</label>
                    <select
                      class="form-select  "
                      aria-label="Default select example"
                      placeholder="IT Sector"
                      value={industry}
                      onChange={(e) => setIndustry(e.target.value)}
                    >
                      <option value="">Choose Industry</option>
                      {allIndustry.map((item, index) => {
                        return (
                          <>
                            <option value={item.title}>{item.title}</option>
                          </>
                        );
                      })}
                    </select>
                  </div>
                </div>
                <div className="col-lg-4 col-md-12 col-12 ">
                  <button className="addExperiencebutton">
                    {" "}
                    Add Experience
                  </button>
                </div>
              </div>
            </div>
              <div className="studentCVdomain_heading">
                <div className="row">
                  <div className="col-12 col-md-12 col-lg-4">
                    <h5>
                      <span>Domain:</span>Technology
                    </h5>
                  </div>
                  <div className="col-12 col-md-12 col-lg-4">
                    <h5>
                      <span>Industry:</span>Retail
                    </h5>
                  </div>
                  <div className="col-12 col-md-12 col-lg-10">
                    <p>
                      In publishing and graphic design, Lorem ipsum is a
                      placeholder text commonly used to demonstrate the
                    </p>
                  </div>
                </div>
                <div className="studentCV_rightIcon">
                  <FiEdit  style={{color:"gray"}}/>
                  <MdAddCircle />
                </div>
              </div>
              <div className="row ">
                <div className="col-12 col-md-12 col-lg-5 ">
                  <div class="form-group">
                    <label for="exampleInputPassword1">Domain</label>
                    <input
                      type="text"
                      class="form-control "
                      id="exampleInputPassword1"
                      placeholder="Enter First Name"
                    />
                  </div>
                  <div class="form-group ">
                    <label for="exampleInputPassword1">Industry</label>
                    <input
                      type="text"
                      class="form-control "
                      placeholder="choose Domain"
                    />
                  </div>
                </div>
                <div className="col-12 col-md-12 col-lg-7  ">
                  <div class="form-group domain_textarea">
                    <textarea
                      type="text"
                      class="form-control "
                      placeholder="Enter some information related Domain and Industry"
                    />
                  </div>
                </div>
              </div>
           <hr className="studentcv_hr"/>
              <div className="row">
                <div classname="col-12 col-md-12 col-lg-12  ">
                  <div class="form-group ">
                    <label for="exampleInputPassword1">Hobbies</label>
                    <input
                      type="text"
                      class="form-control "
                      id="exampleInputPassword1"
                      placeholder="Enter here"
                    />
                  </div>
                </div>
              </div>
              <hr className="studentcv_hr"/>
              <div className="row">
                <div className="col-lg-4 col-md-12 col-12  ">
                  <div class="form-group">
                    <label for="exampleInputPassword1">Recommendation</label>
                    <input
                      type="text"
                      class="form-control "
                      placeholder="Enter here"
                    />
                  </div>
                </div>
                <div className="col-lg-4 col-md-12 col-12  ">
                  <div class="form-group">
                    <label for="exampleInputPassword1">Vendor Name</label>
                    <input
                      type="text"
                      class="form-control "
                      placeholder="Enter here"
                    />
                  </div>
                </div>
                <div className="col-lg-4 col-md-12 col-12  ">
                  <div class="form-group">
                    <label for="exampleInputPassword1">Coach Name</label>
                    <input
                      type="text"
                      class="form-control "
                      placeholder="Enter here"
                    />
                  </div>
                </div>
                <div className="col-lg-4 col-md-12 col-12  ">
                  <div class="form-group">
                    <label for="exampleInputPassword1">
                      Recommendation Detail
                    </label>
                    <input
                      type="text"
                      class="form-control "
                      placeholder="Enter here"
                    />
                  </div>
                </div>
              </div>

              <h5 className="heading_second">Description</h5>

              <div className="col-lg-12 col-md-12 col-12 ">
                <div class="form-group">
                  <textarea
                    type="text"
                    class="form-control"
                    id="exampleInputPassword1"
                    placeholder="Enter here"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                  />
                </div>
              </div>

              
            </div>
          </div>
        
        <div className="formoutline_studentcv">
          <div className="col-12 col-md-12 col-lg-12">
            <div className="row">
              <h5 className="personal_details_heading">Career Objective/Goal</h5>
              <div className="col-lg-4 col-md-12 col-12 ">
                <div class="form-group student_cv_search ">
                  <label for="exampleInputPassword1">I want</label>
                  <span class="search_icon">
                    <FiSearch />
                  </span>

                  <input
                    type="text"
                    class="form-control "
                    placeholder="Enter here"
                  />
                </div>
              </div>
              <div className="col-lg-4 col-md-12 col-12">
                <div class="form-group student_cv_search">
                  <label for="exampleInputPassword1">Domain</label>
                  <span class="search_icon">
                    <FiSearch />
                  </span>

                  <input
                    type="search"
                    class="form-control "
                    placeholder="Enter here"
                  />
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col-lg-4 col-md-12 col-12">
                <div class="form-group student_cv_search">
                  <label for="exampleInputPassword1">Industry</label>

                  <span class="search_icon">
                    <FiSearch />
                  </span>

                  <input
                    type="search"
                    class="form-control "
                    placeholder="Enter here"
                  />
                </div>
              </div>
              <div className="col-lg-4 col-md-12 col-12">
                <div class="form-group student_cv_search">
                  <label for="exampleInputPassword1">Location</label>
                  <span class="location_icon">
                    <BiCurrentLocation />
                  </span>

                  <input
                     type="search"
                    class="form-control "
                    placeholder="Enter here"
                  />
                </div>
              </div>
              <div className="col-lg-4 col-md-12 col-12">
                <div class="form-group  student_cv_search">
                  <label for="exampleInputPassword1">Years of Achieve</label>
                  <span class="search_icon">
                    <FiSearch />
                  </span>

                  <input
                    type="search"
                    class="form-control "
                    placeholder="Enter here"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="row">
           <div className="col-12 col-md-12 col-lg-6 StudentCv_attachFile"> 
           
              <div className=" upload-btn-wrapper">
                <button>
                  {" "}
                  <CgAttachment
                    style={{ fontSize: "25px", color: "#2c6959" }}
                  />
                  Attach File & Document
                </button>
                <input type="file" />
              </div>
            </div>
            <div className="col-lg-3 col-md-6 col-12 ">
            
              <button
                type="submit"
                className="submit_resumeCreationButton"
                onClick={update === true ? updateProfile : submit}
              >
                {" "}
                {loading ? (
                  <Spinner
                    animation="border"
                    variant="light"
                    style={{ width: "20px", height: "20px" }}
                  />
                ) : (
                  "Submit"
                )}
              </button>
              <Spinner />
           
            </div>
            <div className="col-lg-3 col-md-6 col-12 ">
           
              <button type="submit" className=" submit_resumeCreationButton">
                {" "}
                Preview Resume
              </button>
           
         
            </div>
          </div>

          
        <ToastContainer />
      </div>
      <Footer />
    </>
  );
};

export default Student_cv;
